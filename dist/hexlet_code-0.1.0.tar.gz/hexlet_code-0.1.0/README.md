### Hexlet tests and linter status:
[![Actions Status](https://github.com/Garkasha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Garkasha/python-project-49/actions)

### Maintainability Bages
<a href="https://codeclimate.com/github/Garkasha/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c8dda4d49217e4d828e3/maintainability" /></a>


### asciinema Brain Even
https://asciinema.org/a/y8A6yfBqIsEbWjYevD5GiVkQc

### asciinema Brain Calc
https://asciinema.org/a/Y7RvHbFyBEkhluecNmK7sZhu1

### asciinema Brain GCD
https://asciinema.org/a/DCV8TTPv03y8JqnrwMYJoUmRu

### asciinema Brain Progression
https://asciinema.org/a/CLVTqyHVVh38GKu2fohsM2KBy

